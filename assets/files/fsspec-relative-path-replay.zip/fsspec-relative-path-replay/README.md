# fsspec 相对路径下载回放

比较 fsspec PR #2376 合入前后的真实行为：裸相对文件名作为列表元素时，旧版在发出 HTTP 请求前报错；合入版可正常下载。

在本目录运行：

```powershell
python -B -X utf8 run_case.py
```

需要 Python 和 aiohttp。本次已验证 Windows 原生 Python 3.14.3、aiohttp 3.13.5。若当前 Python 没有 aiohttp，可先建独立虚拟环境：

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install aiohttp==3.13.5
.\.venv\Scripts\python -B -X utf8 run_case.py
```

脚本不会自动安装依赖或修改系统 fsspec。首次运行从 GitHub 下载两个固定提交的完整源码，校验 SHA256 后放到 `.work/`；各版在新进程里加载。测试使用真实 `HTTPFileSystem.get` 和本机环回 HTTP 服务。缓存齐备后，以下命令不再下载源码：

```powershell
python -B -X utf8 run_case.py --offline
```

预期输出：

```text
PASS: baseline 2 expected failures + 6 controls; fixed 8 successful transfers.
```

这里的 PASS 表示复现了“原版失败、修复版通过”的预期差异。裸相对文件名的 str/Path 两项在原版失败；六个标量、嵌套和绝对路径对照正常；修复版八项全部下载正确。另有同步 MemoryFileSystem 列表下载参考。

每次运行在 `runs/` 生成新证据目录，记录异常、HTTP 请求数、文件字节校验、源码身份和清理结果。[已验证的结果摘要](results/verified-20261029.json) 对应 2026-10-29 的运行。

| 角色 | 固定提交 |
| --- | --- |
| 合入的直接父提交 | `7aa038375b89d3191ebb81c70162d57441c19f89` |
| 已合入的修复 | `f4fd0f240eb86b5b66adc425f6c2655d839764a4` |

源码包只在实现、HTTP 回归测试和 changelog 三个文件上有差异，脚本会核验。下载文件、缓存和结果均写在本目录内；测试不使用 GPU、模型或外部云存储服务。未运行全项目测试，也不提供性能或全后端结论。

公开 PR、源码和归属见 [SOURCES.md](SOURCES.md)。
