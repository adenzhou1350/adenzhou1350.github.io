"""Replay fsspec PR 2376 using two unmodified public source snapshots.

Preparation downloads pinned GitHub archives. Each probe permits only its own
loopback HTTP endpoint and writes below this package's runs directory.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
REVISIONS = {
    "baseline": "7aa038375b89d3191ebb81c70162d57441c19f89",
    "fixed": "f4fd0f240eb86b5b66adc425f6c2655d839764a4",
}
ARCHIVE_SHA256 = {
    "baseline": "e5d0a4495b6320d42b18dba698a08ec04a65d509fbf4d24bf5d0f8830ef9d82a",
    "fixed": "e1316638b8b36137bbd0e6afb80ce66ca0a34ee1617c8e1aa9730621981d9ecc",
}
EXPECTED_CHANGES = {
    "docs/source/changelog.rst",
    "fsspec/asyn.py",
    "fsspec/implementations/tests/test_http.py",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def source_tree(path):
    return {p.relative_to(path).as_posix(): digest(p.read_bytes())
            for p in sorted(path.rglob("*")) if p.is_file()}


def prepare_sources(offline):
    cache = ROOT / ".work"
    cache.mkdir(exist_ok=True)
    trees, manifests = {}, {}
    for label, commit in REVISIONS.items():
        archive = cache / (commit + ".zip")
        url = "https://codeload.github.com/fsspec/filesystem_spec/zip/" + commit
        if not archive.exists():
            if offline:
                raise RuntimeError("Missing cached public archive: " + archive.name)
            request = urllib.request.Request(url, headers={"User-Agent": "fsspec-case-replay"})
            with urllib.request.urlopen(request, timeout=30) as response:
                data = response.read(20_000_001)
            if len(data) > 20_000_000:
                raise RuntimeError("Unexpected archive size")
            archive.write_bytes(data)
        data = archive.read_bytes()
        if digest(data) != ARCHIVE_SHA256[label]:
            raise RuntimeError("Public archive differs from the reviewed bytes: " + commit)
        destination = cache / ("source-" + commit)
        if not destination.exists():
            destination.mkdir()
            with zipfile.ZipFile(io.BytesIO(data)) as bundle:
                for item in bundle.infolist():
                    target = (destination / item.filename).resolve()
                    if not target.is_relative_to(destination.resolve()):
                        raise RuntimeError("Archive path escapes extraction directory")
                    if (item.external_attr >> 16) & 0o170000 == 0o120000:
                        raise RuntimeError("Symlinks are not needed by this replay")
                bundle.extractall(destination)
        source = destination / ("filesystem_spec-" + commit)
        if not (source / "fsspec/asyn.py").is_file():
            raise RuntimeError("Incomplete source extraction: " + commit)
        with zipfile.ZipFile(io.BytesIO(data)) as bundle:
            prefix = "filesystem_spec-" + commit + "/"
            expected_files = {item.filename.removeprefix(prefix): digest(bundle.read(item))
                              for item in bundle.infolist() if not item.is_dir()}
        if source_tree(source) != expected_files:
            raise RuntimeError("Extracted source differs from its pinned archive: " + commit)
        trees[label] = source
        manifests[label] = {
            "commit": commit, "download_url": url,
            "archive_sha256": digest(data), "files": source_tree(source),
        }
    before, after = (manifests[key]["files"] for key in ("baseline", "fixed"))
    changes = sorted(p for p in set(before) | set(after) if before.get(p) != after.get(p))
    if set(changes) != EXPECTED_CHANGES:
        raise RuntimeError("Unexpected differences between public sources: " + repr(changes))
    return trees, manifests, changes


def probe(source, output):
    """Call the ordinary HTTPFileSystem.get API, without replacing fsspec code."""
    import threading
    import traceback
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    import importlib.metadata

    source = source.resolve()
    output = output.resolve()
    if not output.is_relative_to(ROOT / "runs"):
        raise ValueError("Probe output must remain below this package's runs directory")
    sys.path.insert(0, str(source))
    import fsspec
    from fsspec.implementations.http import HTTPFileSystem

    if not Path(fsspec.__file__).resolve().is_relative_to(source):
        raise RuntimeError("Wrong fsspec source imported")
    original_tree = source_tree(source)
    payload = b"fsspec relative destination replay\x00\xff\n"
    observed_requests = []
    permitted_port = None
    # Windows' asyncio loop makes its own loopback socket pair during setup.
    # Build that local event loop before restricting transfer connections.
    fs = HTTPFileSystem(skip_instance_cache=True, client_kwargs={"trust_env": False})

    def audit_guard(event, args):
        if event == "socket.connect":
            address = args[1]
            if not (isinstance(address, tuple) and address == ("127.0.0.1", permitted_port)):
                raise RuntimeError("Unexpected network destination")
        if event == "socket.bind" and args[1] != ("127.0.0.1", 0):
            raise RuntimeError("Unexpected listening address")
        if event in ("subprocess.Popen", "os.system", "os.posix_spawn", "os.spawn"):
            raise RuntimeError("External process launch is not part of the probe")

    sys.addaudithook(audit_guard)

    class Handler(BaseHTTPRequestHandler):
        def reply(self, send_body):
            observed_requests.append({"method": self.command, "path": self.path})
            self.send_response(200)
            self.send_header("Content-Length", str(len(payload)))
            self.send_header("Content-Type", "application/octet-stream")
            self.end_headers()
            if send_body:
                self.wfile.write(payload)

        def do_HEAD(self):
            self.reply(False)

        def do_GET(self):
            self.reply(True)

        def log_message(self, *_):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    permitted_port = server.server_address[1]
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    url = "http://127.0.0.1:" + str(permitted_port) + "/payload"
    previous = Path.cwd()
    scratch = output.parent / (output.stem + "-files")
    scratch.mkdir(exist_ok=False)
    cases = []
    try:
        for mode in ("scalar", "bare_list", "nested_list", "absolute_list"):
            for path_kind in ("str", "Path"):
                name = mode + "_" + path_kind
                work = scratch / name
                work.mkdir()
                os.chdir(work)
                relative = "nested/result.bin" if mode == "nested_list" else "result.bin"
                target = (work / relative) if mode == "absolute_list" else Path(relative)
                target = str(target) if path_kind == "str" else target
                remote, destination = (url, target) if mode == "scalar" else ([url], [target])
                before_requests = len(observed_requests)
                directory_calls, error, frames = [], None, []
                original_makedirs = os.makedirs

                def observe_makedirs(path, *args, **kwargs):
                    directory_calls.append(os.fspath(path))
                    return original_makedirs(path, *args, **kwargs)

                try:
                    os.makedirs = observe_makedirs
                    fs.get(remote, destination)
                except Exception as exc:
                    error = {"type": type(exc).__name__, "message": str(exc)}
                    frames = [{"file": Path(frame.filename).name, "line": frame.lineno,
                               "function": frame.name, "code": frame.line}
                              for frame in traceback.extract_tb(exc.__traceback__)]
                finally:
                    os.makedirs = original_makedirs
                exists = Path(target).is_file()
                valid_bytes = exists and Path(target).read_bytes() == payload
                cases.append({"name": name, "error": error, "traceback": frames,
                              "output_present": exists, "bytes_equal": valid_bytes,
                              "requests": len(observed_requests) - before_requests,
                              "mkdir_arguments": directory_calls})
        memory = fsspec.filesystem("memory", skip_instance_cache=True)
        memory.pipe("/replay-source", payload)
        memory.get(["/replay-source"], ["memory-reference.bin"])
        memory_control = Path("memory-reference.bin").read_bytes() == payload
    finally:
        os.chdir(previous)
        if fs._session is not None:
            HTTPFileSystem.close_session(fs.loop, fs._session)
        server.shutdown()
        server.server_close()
        server_thread.join(timeout=5)
    unchanged = original_tree == source_tree(source)
    value = {
        "python": sys.version, "aiohttp_version": importlib.metadata.version("aiohttp"),
        "source_commit": source.name.removeprefix("filesystem_spec-"),
        "asyn_sha256": digest((source / "fsspec/asyn.py").read_bytes()),
        "source_unchanged": unchanged, "cases": cases,
        "synchronous_memory_control_passed": memory_control,
        "http_client_closed": fs._session is not None and fs._session.closed,
        "http_server_thread_stopped": not server_thread.is_alive(),
        "scope": "Real HTTPFileSystem.get; owned loopback HTTP fixture; no cloud or full suite.",
    }
    write_json(output, value)
    print(json.dumps(value, ensure_ascii=False, indent=2))
    return 0 if unchanged and memory_control and value["http_client_closed"] and value["http_server_thread_stopped"] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--offline", action="store_true", help="Use already downloaded archives only")
    parser.add_argument("--probe", type=Path, help=argparse.SUPPRESS)
    parser.add_argument("--output", type=Path, help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.probe:
        return probe(args.probe, args.output)
    if importlib.util.find_spec("aiohttp") is None:
        raise SystemExit("aiohttp is missing. See README for an optional isolated venv; nothing was installed.")
    sources, manifests, changes = prepare_sources(args.offline)
    run = ROOT / "runs" / datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    run.mkdir(parents=True, exist_ok=False)
    write_json(run / "source-manifest.json", {"sources": manifests, "changed_files": changes})
    results = {}
    for label in ("baseline", "fixed"):
        command = [sys.executable, "-B", "-X", "utf8", str(Path(__file__).resolve()),
                   "--probe", str(sources[label]), "--output", str(run / (label + ".json"))]
        process = subprocess.run(command, cwd=ROOT, text=True, encoding="utf-8", capture_output=True, timeout=45)
        (run / (label + ".stdout.txt")).write_text(process.stdout, encoding="utf-8")
        (run / (label + ".stderr.txt")).write_text(process.stderr, encoding="utf-8")
        if process.returncode:
            raise RuntimeError(label + " probe failed; inspect " + str(run))
        results[label] = json.loads((run / (label + ".json")).read_text(encoding="utf-8"))
    expected_failures = {"bare_list_str", "bare_list_Path"}
    checks = []
    for label, result in results.items():
        for case in result["cases"]:
            expected_failure = label == "baseline" and case["name"] in expected_failures
            if expected_failure:
                passed = (case["error"] is not None and case["error"]["type"] == "FileNotFoundError"
                          and case["requests"] == 0 and not case["output_present"]
                          and "" in case["mkdir_arguments"])
            else:
                passed = case["error"] is None and case["bytes_equal"]
                if label == "fixed":
                    passed = passed and all(p not in ("", ".") for p in case["mkdir_arguments"])
            checks.append({"revision": label, "case": case["name"], "expectation_met": passed})
    value = {"status": "PASS" if all(c["expectation_met"] for c in checks) else "FAIL",
             "checked_at_utc": datetime.now(timezone.utc).isoformat(), "revisions": REVISIONS,
             "checks": checks, "baseline_expected_failures": sorted(expected_failures),
             "note": "PASS means the comparison reproduced the defect and repair; baseline is not passing software."}
    write_json(run / "comparison.json", value)
    print("PASS: baseline 2 expected failures + 6 controls; fixed 8 successful transfers."
          if value["status"] == "PASS" else "FAIL: observed behavior differs from the recorded expectations.")
    print("Evidence: " + str(run))
    return 0 if value["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
