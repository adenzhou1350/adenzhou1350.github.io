# 来源与归属

- 问题与上游评审：[fsspec/filesystem_spec#2376](https://github.com/fsspec/filesystem_spec/pull/2376)。提交者 adenzhou1350；维护者 martindurant 于 2026-10-27 合入。
- 原版：[7aa038375b89d3191ebb81c70162d57441c19f89](https://github.com/fsspec/filesystem_spec/commit/7aa038375b89d3191ebb81c70162d57441c19f89)。这是最终合入提交的直接父提交。
- 修复版：[f4fd0f240eb86b5b66adc425f6c2655d839764a4](https://github.com/fsspec/filesystem_spec/commit/f4fd0f240eb86b5b66adc425f6c2655d839764a4)。最终实现仅在父目录非空时创建它。

`run_case.py` 是为本案例新写的独立复现脚本，调用公开 fsspec API；不包含 fsspec 的实现代码。脚本下载未经修改的完整上游源码，保留其中的 [BSD-3-Clause LICENSE](https://github.com/fsspec/filesystem_spec/blob/f4fd0f240eb86b5b66adc425f6c2655d839764a4/LICENSE) 及原署名。上游版权为 Martin Durant 等原权利人所有；本包不改变其许可。

`results/verified-20261029.json` 来自本次 Windows 原生环境的真实回放，包含固定版本、源码哈希、逐项结果和清理状态。它省去了机器路径，保留了复核行为差异所需的信息。它不代表官方 CI 或所有平台的验收。

本包提供原创脚本用于文章复现，没有另行指定新的软件许可证。
